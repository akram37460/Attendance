
<?php
session_start();
error_reporting(0);

require('../connect.php');
    // If the values are posted, insert them into the database.
	$email='';
    if (isset($_POST['email']) && isset($_POST['password'])){
        $username = $_POST['email'];
		$companyId = $_REQUEST['id'];	
		$employeeId = $_POST['emp_id'];		
		$employeename = $_POST['emp_name'];		
		$employee_desg = $_POST['emp_desg'];
		$employee_mobile = $_POST['emp_mobile'];
		$password= $_POST['password'];
		$status=1;
		
		
        $password = $_POST['password'];
      $query = "INSERT INTO `emp_master` (company_id, emp_id, emp_name,  emp_desg, status,emp_mobile, emailid,   passWord) VALUES ('$companyId','$employeeId','$employeename','$employee_desg','$status','$employee_mobile', '$username', '$password' )";
        $result = mysqli_query($connection, $query);
        if($result){
            $smsg = "Company account Created Successfully.";
        }else{
            $fmsg ="Company account  Registration Failed";
        }
    }
    ?>
<html>
<head>
<title>PresentSir</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="../css/bootstrap.min.css" > 
<!-- Optional theme -->
<link rel="stylesheet" href="../css/bootstrap-theme.min.css" >
<link rel="stylesheet" href="styles.css" > 
<!-- Latest compiled and minified JavaScript -->
<script src="../js/bootstrap.min.js"></script>
</head>
<body>
 
<div class="container">
      <form class="form-signin" method="POST">
      
      <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
      <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
     <!--   <h2 class="form-signin-heading">Please Register</h2>-->
		
        <div class="input-group">
		<div class="col-xs-6 col-md-offset-4">
  <span class="input-group-addon" id="basic-addon1"><h3><?=$_SESSION['companyName'];?><br>Register</h3></span>
  <input type="text" name="email" class="form-control" placeholder="Useremail" required>
</div>
<div class="col-xs-6 col-md-offset-4">
 <label for="inputcompanyId" class="sr-only">Company id</label>
   <input type="hidden" name="companyId" value="<?=$_SESSION['id']?>" class="form-control" placeholder="<?=$_SESSION['companyName'];?>" disabled>
 
		<label for="inputemp_code" class="sr-only">Emp_Code</label>
        <input type="text" name="emp_id" id="inputcompanyAddress" class="form-control" placeholder="Employee ID numeric value " required autofocus>
		
		<label for="inputemp_name" class="sr-only">Employee Name</label>
        <input type="text" name="emp_name" id="inputemp_name" class="form-control" placeholder="Employee name" required autofocus>
		
		<label for="inputemp_desg" class="sr-only">Employee Designation</label>
        <input type="text" name="emp_desg" id="inputdesg" class="form-control" placeholder="Employee Designation" required autofocus>
       
		<label for="inputemp_mobile" class="sr-only">Employee Mobile</label>
        <input type="text" name="emp_mobile" id="inputmobile" class="form-control" placeholder="Employee Mobile" required autofocus>
       
	   <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" required>
     
        <button class="btn btn-lg btn-primary btn-block" type="submit">Register</button>
      <a class="btn btn-lg btn-primary btn-block" href="../admin/index.php?filter=0">Home</a>
      </form>
</div>
 
</body>
 
</html>