<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MBA</title>
<link rel="stylesheet" href="dist/bootstrap.min.css" type="text/css" media="all">
<link href="dist/jquery.bootgrid.css" rel="stylesheet" />
<script src="dist/jquery-1.11.1.min.js"></script>
<script src="dist/bootstrap.min.js"></script>
<script src="dist/jquery.bootgrid.min.js"></script>
<div class="container">
<?php
include "container.php";
 require('../connect.php');
//$_SESSION['emp_id']=$_REQUEST['filter'];
$sql="SELECT id,emp_name,emp_desg,company_id FROM emp_master";
$result=mysqli_query($connection,$sql);
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
$sql1="SELECT company_master.id,company_master.companyName, emp_master.company_id FROM company_master , emp_master WHERE emp_master.company_id=company_master.company_id";
$result1=mysqli_query($connection,$sql1);
$result=mysqli_query($connection,$sql);
$row1=mysqli_fetch_array($result1,MYSQLI_ASSOC);
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
?>
      <div class="">
        <h1><a href="#" target="_blank" rel="nofollow" class="link-red">MBA</a></h1>
        <div class="">
		<table id="employee_grid" class="table table-condensed table-hover table-striped" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th data-column-id="id" data-type="numeric">#id</th>
                <th data-column-id="emp_id">Emp_Id</th>
				<th data-column-id="ip">IP</th>
                <th data-column-id="month">Month</th>
				 <th data-column-id="timestamp">TimeStamp</th>
            </tr>
        </thead>
 
        
    </table>
    </div>
      </div>

    </div>

<script type="text/javascript">
$( document ).ready(function() {
	$("#employee_grid").bootgrid({
		ajax: true,
		post: function ()
		{
			/* To accumulate custom parameter with the request object */
			return {
				id: "b0df282a-0d67-40e5-8558-c9e93b7befed"
			};
		},
		url: "response.php",
		formatters: {
			
		}
   });
});
</script>
